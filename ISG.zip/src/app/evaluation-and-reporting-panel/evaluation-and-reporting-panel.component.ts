import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evaluation-and-reporting-panel',
  templateUrl: './evaluation-and-reporting-panel.component.html',
  styleUrls: ['./evaluation-and-reporting-panel.component.scss']
})
export class EvaluationAndReportingPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
