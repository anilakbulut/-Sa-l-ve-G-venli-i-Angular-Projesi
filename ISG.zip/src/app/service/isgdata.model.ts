export interface isgData{
    id?:string;
    konum?:string;
    tur?:string;
    bina?:string;
    raporturu?:string;
    bildiren?:string;
    aciklama?:string;
}