export interface FilterData{
    viewBuild: string;
    viewArea: string;
    viewTypeOfAccident: string;
    viewTypeOfReport: string;
  }