import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-update-delete-panel',
  templateUrl: './add-update-delete-panel.component.html',
  styleUrls: ['./add-update-delete-panel.component.scss']
})
export class AddUpdateDeletePanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
