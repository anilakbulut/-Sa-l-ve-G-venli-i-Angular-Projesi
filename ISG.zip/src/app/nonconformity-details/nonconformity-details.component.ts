import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nonconformity-details',
  templateUrl: './nonconformity-details.component.html',
  styleUrls: ['./nonconformity-details.component.scss']
})
export class NonconformityDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
